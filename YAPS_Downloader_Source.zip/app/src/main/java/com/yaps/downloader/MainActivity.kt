package com.yaps.downloader

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.InputType
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.net.URI

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 11, 10)
    private val panel = Color.rgb(22, 25, 23)
    private val accent = Color.rgb(184, 255, 92)
    private val muted = Color.rgb(158, 165, 159)
    private lateinit var urlInput: EditText
    private lateinit var platformLabel: TextView
    private lateinit var status: TextView
    private lateinit var quality: Spinner
    private lateinit var format: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(20))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply {
            text = "YAPS"; textSize = 30f; setTextColor(accent)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "DOWNLOADER  •  VIDEO & AUDIO"; textSize = 11f
            setTextColor(muted); letterSpacing = .12f
        }.withMargins(bottom = 26))

        content.addView(TextView(this).apply {
            text = "Simpan media favoritmu"; textSize = 24f
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        content.addView(TextView(this).apply {
            text = "Tempel tautan video untuk memulai."; textSize = 14f
            setTextColor(muted)
        }.withMargins(bottom = 20, top = 6))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = rounded(panel, 18)
        }
        card.addView(label("TAUTAN VIDEO"))
        urlInput = EditText(this).apply {
            hint = "Tempel link YouTube, TikTok, Instagram…"
            setHintTextColor(Color.rgb(105, 112, 106))
            setTextColor(Color.WHITE); textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 3
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(34, 38, 35), 12)
        }
        card.addView(urlInput, lp(match, wrap, top = 8))
        val paste = Button(this).apply {
            text = "TEMPEL DARI PAPAN KLIP"
            setTextColor(accent); textSize = 12f
            background = rounded(Color.rgb(42, 52, 39), 10)
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                urlInput.setText(clipboard.primaryClip?.getItemAt(0)?.coerceToText(this@MainActivity) ?: "")
                detectPlatform()
            }
        }
        card.addView(paste, lp(match, dp(46), top = 10))
        platformLabel = TextView(this).apply {
            text = "PLATFORM  •  Belum terdeteksi"; setTextColor(muted); textSize = 12f
        }
        card.addView(platformLabel, lp(match, wrap, top = 12))
        content.addView(card, lp(match, wrap, bottom = 20))

        content.addView(label("FORMAT"))
        format = Spinner(this).apply {
            adapter = spinnerAdapter(listOf("Video (MP4)", "Audio (MP3 — jika tersedia)"))
        }
        content.addView(format, lp(match, dp(52), top = 8, bottom = 16))

        content.addView(label("KUALITAS VIDEO"))
        quality = Spinner(this).apply {
            adapter = spinnerAdapter(listOf("Otomatis / terbaik tersedia", "1080p", "720p", "480p", "360p"))
        }
        content.addView(quality, lp(match, dp(52), top = 8, bottom = 20))

        val download = Button(this).apply {
            text = "LANJUTKAN  →"; textSize = 14f
            setTextColor(Color.rgb(12, 15, 10)); typeface = Typeface.DEFAULT_BOLD
            background = rounded(accent, 14)
            setOnClickListener { handleDownloadRequest() }
        }
        content.addView(download, lp(match, dp(54), bottom = 14))

        status = TextView(this).apply {
            text = "Siap digunakan"; textSize = 13f; setTextColor(muted)
        }
        content.addView(status)

        content.addView(TextView(this).apply {
            text = "\nCatatan: aplikasi ini adalah kerangka awal. Pengunduhan dari link platform belum diintegrasikan; dukungan bergantung pada akses dan ketentuan masing-masing layanan."
            textSize = 12f; setTextColor(muted)
        }.withMargins(top = 18))

        scroll.addView(content)
        setContentView(scroll)
        handleIntentText()
    }

    private fun handleIntentText() {
        if (intent?.action == android.content.Intent.ACTION_SEND &&
            intent.type == "text/plain") {
            urlInput.setText(intent.getStringExtra(android.content.Intent.EXTRA_TEXT) ?: "")
            detectPlatform()
        }
    }

    private fun detectPlatform() {
        val raw = urlInput.text.toString().trim()
        val host = try { URI(raw).host?.lowercase() ?: "" } catch (_: Exception) { "" }
        val platform = when {
            host.contains("youtube.com") || host == "youtu.be" -> "YouTube"
            host.contains("tiktok.com") -> "TikTok"
            host.contains("instagram.com") -> "Instagram"
            raw.isBlank() -> "Belum terdeteksi"
            else -> "Tautan langsung / lainnya"
        }
        platformLabel.text = "PLATFORM  •  $platform"
    }

    private fun handleDownloadRequest() {
        val raw = urlInput.text.toString().trim()
        if (raw.isBlank()) {
            status.text = "Masukkan tautan terlebih dahulu."
            return
        }
        val uri = try { URI(raw) } catch (_: Exception) { null }
        if (uri == null || uri.scheme !in listOf("https", "http") || uri.host.isNullOrBlank()) {
            status.text = "Tautan tidak valid. Gunakan link lengkap yang diawali https://"
            return
        }
        detectPlatform()
        val host = uri.host.lowercase()
        val platformLink = host.contains("youtube.com") || host == "youtu.be" ||
                host.contains("tiktok.com") || host.contains("instagram.com")
        status.text = if (platformLink) {
            "Link terdeteksi. Mesin pengunduh platform belum terpasang pada versi awal ini."
        } else {
            "Link valid. Unduhan langsung belum diaktifkan pada kerangka awal ini."
        }
        AlertDialog.Builder(this)
            .setTitle("Mesin download belum terintegrasi")
            .setMessage("Tampilan dan validasi tautan sudah tersedia. Untuk mengunduh video/audio sungguhan, proyek ini masih memerlukan modul pengunduh yang kompatibel dan sesuai ketentuan platform.")
            .setPositiveButton("Mengerti", null)
            .show()
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text; textSize = 11f; setTextColor(muted)
        typeface = Typeface.DEFAULT_BOLD; letterSpacing = .08f
    }

    private fun spinnerAdapter(items: List<String>): ArrayAdapter<String> =
        object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                return super.getView(position, convertView, parent).apply {
                    (this as TextView).setTextColor(Color.WHITE); textSize = 14f
                }
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
                return super.getDropDownView(position, convertView, parent).apply {
                    (this as TextView).setTextColor(Color.WHITE)
                    setBackgroundColor(panel); textSize = 14f
                }
            }
        }.also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply {
            topMargin = dp(top); bottomMargin = dp(bottom)
        }
    private fun TextView.withMargins(top: Int = 0, bottom: Int = 0) =
        this.apply { layoutParams = lp(match, wrap, top, bottom) }
    companion object { const val match = ViewGroup.LayoutParams.MATCH_PARENT; const val wrap = ViewGroup.LayoutParams.WRAP_CONTENT }
}
