# YAPS Downloader — Android starter project

A dark, minimal Kotlin Android Studio starter for Redmi Note 10 5G / Android 8.0+.

## Current state
- Dark minimal UI branded YAPS Downloader
- Paste clipboard link
- Detect YouTube, TikTok, Instagram, and other URL hosts
- Select intended format (video/audio) and quality
- Validate URL and support receiving shared text links

## Important limitation
This starter project does **not** yet download media. The download engine is intentionally not faked: platform extraction and audio conversion require a separate, maintained implementation and must respect each service's terms, access controls, and copyright. Direct media URL downloading also needs a real download worker and storage handling.

## Build APK
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle to sync (internet required).
4. Use **Build > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.

This environment has generated the source project, not compiled or tested an APK.
